--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6
-- Dumped by pg_dump version 12.3

-- Started on 2020-08-27 22:02:04

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3878 (class 1262 OID 16402)
-- Name: usbankpoc; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE usbankpoc WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE usbankpoc OWNER TO postgres;

\connect usbankpoc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 212 (class 1255 OID 16446)
-- Name: get_all_customers(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_all_customers() RETURNS TABLE(id integer, custname text, email text, age integer, address text)
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN QUERY 
    SELECT c.custid,c.custname,c.email,c.age,c.address from public.customer c;
END;
$$;


ALTER FUNCTION public.get_all_customers() OWNER TO postgres;

--
-- TOC entry 213 (class 1255 OID 16427)
-- Name: insert_data(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_data(a integer, b integer)
    LANGUAGE sql
    AS $$
INSERT INTO customer(custname,email,age,address) VALUES ('test','sdg',4,'sdfgg');

$$;


ALTER PROCEDURE public.insert_data(a integer, b integer) OWNER TO postgres;

--
-- TOC entry 216 (class 1255 OID 32892)
-- Name: insert_something(text, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_something(_id text, _val integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE count int;
BEGIN
    INSERT INTO customer (custname, age) VALUES(_id, _val);
    GET DIAGNOSTICS count = ROW_COUNT;
    RETURN count;
END;
$$;


ALTER FUNCTION public.insert_something(_id text, _val integer) OWNER TO postgres;

--
-- TOC entry 215 (class 1255 OID 32883)
-- Name: sample_insert(text, text, integer, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sample_insert(_customer text, _email text, _age integer, _address text)
    LANGUAGE sql
    AS $$

     INSERT INTO customer(custname, email, age, address)

     VALUES(_customer, _email, _age, _address)   
     
     RETURNING custid;

 $$;


ALTER PROCEDURE public.sample_insert(_customer text, _email text, _age integer, _address text) OWNER TO postgres;

--
-- TOC entry 214 (class 1255 OID 16428)
-- Name: select_customer(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.select_customer()
    LANGUAGE sql
    AS $$
select "custid","custname","email","age","address" from customer
$$;


ALTER PROCEDURE public.select_customer() OWNER TO postgres;

SET default_tablespace = '';

--
-- TOC entry 201 (class 1259 OID 32803)
-- Name: businesslines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.businesslines (
    id integer NOT NULL,
    businesscode character varying(25) NOT NULL,
    businessline character varying(100) NOT NULL,
    businesslinetype character varying(100) NOT NULL,
    status character(1),
    datecreated timestamp without time zone,
    datemodified timestamp without time zone,
    modifiedby character varying(10)
);


ALTER TABLE public.businesslines OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 32801)
-- Name: businesslines_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.businesslines ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.businesslines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 203 (class 1259 OID 32810)
-- Name: ctrlog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctrlog (
    ctrlogid integer NOT NULL,
    ctrnumber character varying(15),
    inputdate timestamp without time zone NOT NULL,
    trandate timestamp without time zone,
    completiondate timestamp without time zone,
    username character varying(10) NOT NULL,
    tin character varying(15),
    accountnumber character varying(100),
    businessline character varying(25),
    businessindividualname character varying(100),
    amount numeric(18,2) NOT NULL,
    trantype character varying(50),
    trannum character varying(50),
    branchnum character varying(50),
    tellernum character varying(50),
    researchrcvd bit(1),
    micl character varying(10),
    archived bit(1),
    archiveddate timestamp without time zone,
    archivedby character varying(10),
    exem character varying(20)
);


ALTER TABLE public.ctrlog OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 32808)
-- Name: ctrlog_ctrlogid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.ctrlog ALTER COLUMN ctrlogid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ctrlog_ctrlogid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 205 (class 1259 OID 32829)
-- Name: ctrlog_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ctrlog_notes (
    notesid integer NOT NULL,
    username character varying(10) NOT NULL,
    comments character varying(2048),
    notesdate timestamp without time zone NOT NULL,
    ctrlogid integer NOT NULL
);


ALTER TABLE public.ctrlog_notes OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 32827)
-- Name: ctrlog_notes_notesid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.ctrlog_notes ALTER COLUMN notesid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ctrlog_notes_notesid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 197 (class 1259 OID 16416)
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    custid integer NOT NULL,
    custname text NOT NULL,
    email text,
    age integer,
    address text
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 16414)
-- Name: customer_custid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_custid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customer_custid_seq OWNER TO postgres;

--
-- TOC entry 3880 (class 0 OID 0)
-- Dependencies: 196
-- Name: customer_custid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_custid_seq OWNED BY public.customer.custid;


--
-- TOC entry 199 (class 1259 OID 32793)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    userid character varying(50) NOT NULL,
    firstname character varying(255) NOT NULL,
    lastname character varying(255) NOT NULL,
    businessline character varying(25),
    userrole character varying(50),
    status character(1),
    comments character varying(255),
    datecreated timestamp without time zone,
    datemodified timestamp without time zone,
    modifiedby character varying(10)
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 32791)
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employees ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 207 (class 1259 OID 32839)
-- Name: issue_responses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_responses (
    respid integer NOT NULL,
    responsecomment character varying(1024) NOT NULL,
    username character varying(10) NOT NULL,
    responsedate timestamp without time zone NOT NULL,
    issueid integer NOT NULL
);


ALTER TABLE public.issue_responses OWNER TO postgres;

--
-- TOC entry 206 (class 1259 OID 32837)
-- Name: issue_responses_respid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.issue_responses ALTER COLUMN respid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.issue_responses_respid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 209 (class 1259 OID 32849)
-- Name: issue_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issue_types (
    issuetypeid integer NOT NULL,
    customertype character(1) NOT NULL,
    issue character varying(100) NOT NULL,
    issuetype character varying(100) NOT NULL,
    issuesubtype character varying(100),
    status character(1),
    explanation character varying(256),
    expectedresponse character varying(1024),
    amendreview character varying(1),
    reviewdays integer NOT NULL,
    futurereleaseeligible bit(1),
    datecreated timestamp without time zone,
    datemodified timestamp without time zone,
    modifiedby character varying(10),
    missing_type character varying(100)
);


ALTER TABLE public.issue_types OWNER TO postgres;

--
-- TOC entry 208 (class 1259 OID 32847)
-- Name: issue_types_issuetypeid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.issue_types ALTER COLUMN issuetypeid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.issue_types_issuetypeid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 211 (class 1259 OID 32861)
-- Name: issues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.issues (
    issueid integer NOT NULL,
    ctrlogid integer NOT NULL,
    username character varying(10) NOT NULL,
    customertype character varying(1),
    issueshortname character varying(100),
    issuecomment character varying(1024),
    reviewercomment character varying(1024),
    missing_type character varying(50),
    issuetype character varying(100) NOT NULL,
    issuesubtype character varying(100),
    issuestatus character varying(100),
    entrydate timestamp without time zone NOT NULL,
    duedate timestamp without time zone,
    reviewbydate timestamp without time zone,
    acctclosuredate timestamp without time zone,
    dateresolved timestamp without time zone,
    datecompleted timestamp without time zone,
    resassignedun character varying(10),
    resassigndate timestamp without time zone,
    moreinfoneeded character varying(1) NOT NULL,
    unresolveableitem bit(1),
    futurereleaseitem bit(1),
    issuebusinessline character varying(100),
    reopendate timestamp without time zone,
    reopenby character varying(50)
);


ALTER TABLE public.issues OWNER TO postgres;

--
-- TOC entry 210 (class 1259 OID 32859)
-- Name: issues_issueid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.issues ALTER COLUMN issueid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.issues_issueid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 3735 (class 2604 OID 16419)
-- Name: customer custid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN custid SET DEFAULT nextval('public.customer_custid_seq'::regclass);


--
-- TOC entry 3741 (class 2606 OID 32807)
-- Name: businesslines businesslines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businesslines
    ADD CONSTRAINT businesslines_pkey PRIMARY KEY (businesscode);


--
-- TOC entry 3745 (class 2606 OID 32836)
-- Name: ctrlog_notes ctrlog_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctrlog_notes
    ADD CONSTRAINT ctrlog_notes_pkey PRIMARY KEY (notesid);


--
-- TOC entry 3743 (class 2606 OID 32817)
-- Name: ctrlog ctrlog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ctrlog
    ADD CONSTRAINT ctrlog_pkey PRIMARY KEY (ctrlogid);


--
-- TOC entry 3737 (class 2606 OID 16424)
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (custid);


--
-- TOC entry 3739 (class 2606 OID 32800)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (userid);


--
-- TOC entry 3747 (class 2606 OID 32846)
-- Name: issue_responses issue_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_responses
    ADD CONSTRAINT issue_responses_pkey PRIMARY KEY (respid);


--
-- TOC entry 3749 (class 2606 OID 32856)
-- Name: issue_types issue_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issue_types
    ADD CONSTRAINT issue_types_pkey PRIMARY KEY (issuetypeid);


--
-- TOC entry 3751 (class 2606 OID 32868)
-- Name: issues issues_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.issues
    ADD CONSTRAINT issues_pkey PRIMARY KEY (issueid);


--
-- TOC entry 3879 (class 0 OID 0)
-- Dependencies: 3
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM rdsadmin;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


-- Completed on 2020-08-27 22:02:29

--
-- PostgreSQL database dump complete
--

